面试题 

360 将大厂更大家见面  树立目标

css 表示能力很强， 现代变革让css 具有了编程语言的能力， 请问那些方面或技术可以
让css 更具程序表达能力  ?
stylus  变量定义  嵌套， 函数，  css 预编译
还有其他方法吗？

- css4 推出了css variable 能力， 可以实现stylus(预编译) 一样的效果 , css4是原生支持的
- 3%  回答呢？  
  stylus 在头部定义变量   variable = value 
  把变量集中在头部定义， 方便修改和管理 
  stylus 并不需要$   但是我们用$   良好的编程风格， php $variable 
- css3  css4
  每一代有一些新特性 ，  列举一些css3 的新特性吗？
  animation(复杂动画设计)  transition(css属性修改带来过度)
  translate3d transform
  box-shadow
  flex 
  linear-gradient
  盒子模型  css2   flex 带来新的盒子能力，   
  box-sizing:border-box  盒子模型  在css3 里的全新计算方式
  position  
  rgba() 带有透明特性的
  grid  布局， filter  
  围绕面试来说， 70% 可以在面试里回答上来了

-  弹性布局 flex 
  三栏布局， 传统的双飞翼， 圣杯可以了， 
  面试里， 表达创新， flex 布局挺好的
  main 放到第一位？ 优先现实， 用户先看到主题内容， 最重要。 
  页面我们看到， 是绘制出来的， 重绘 重排
  绘制页面（布局， 大小， 颜色）需要花时间， main区域内容重要， 吸引用户眼球， 优先绘制很重要， 眼睛感觉的时间差  60FPS 
  order: -1  position/ 