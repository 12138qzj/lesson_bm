- 没有使用create-react-app   react 开发的脚手架
  从0 开发构建一个react 项目 webpack  开发打包工具, 
  react 开发流程  webpack    ts  react + react-router  redux 
  1. webpack  开发流程工具
  2. webpack-cli  commend line 开发工具的命令行工具
  3. webpack-dev-server 3000 启动我们的应用...

- scripts  webpack-dev-server   3000  运行dev 项目

- typescript tsconfig.json根目录下的ts 配置

- @babel/core    es6 -> es5
  .babelrc   处理js 

- bootstrap 前端css 框架